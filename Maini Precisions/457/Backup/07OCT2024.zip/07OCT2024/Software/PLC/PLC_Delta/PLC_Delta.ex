﻿<?xml version="1.0" encoding="utf-8" standalone="no"?>
<Configuration MasterDeviceType="33554450">
  <TotalData>
    <Ports>
      <Port Index="1">
        <Tables>
          <Table ProtocolType="Modbus" Mode="2" AutoScan="0">
            <Blocks>
              <Block Enable="256" StationAddr="512" DeviceTypeCode="71776121351897087" In_Address="3087728640" Out_Address="2685337600" Read_Address="119668736" Write_Address="119668736" Read_Amount="10240" Write_Amount="10240" W_FuncCode="4096" R_FuncCode="768" Interval_Time="12800" TimeOut="25600" AddrType="0" />
              <Block Enable="0" StationAddr="0" DeviceTypeCode="0" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="0" Write_Amount="0" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0" />
              <Block Enable="0" StationAddr="0" DeviceTypeCode="0" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="0" Write_Amount="0" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0" />
              <Block Enable="0" StationAddr="0" DeviceTypeCode="0" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="0" Write_Amount="0" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0" />
              <Block Enable="0" StationAddr="0" DeviceTypeCode="0" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="0" Write_Amount="0" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0" />
              <Block Enable="0" StationAddr="0" DeviceTypeCode="0" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="0" Write_Amount="0" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0" />
              <Block Enable="0" StationAddr="0" DeviceTypeCode="0" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="0" Write_Amount="0" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0" />
              <Block Enable="0" StationAddr="0" DeviceTypeCode="0" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="0" Write_Amount="0" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0" />
              <Block Enable="0" StationAddr="0" DeviceTypeCode="0" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="0" Write_Amount="0" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0" />
              <Block Enable="0" StationAddr="0" DeviceTypeCode="0" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="0" Write_Amount="0" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0" />
              <Block Enable="0" StationAddr="0" DeviceTypeCode="0" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="0" Write_Amount="0" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0" />
              <Block Enable="0" StationAddr="0" DeviceTypeCode="0" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="0" Write_Amount="0" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0" />
              <Block Enable="0" StationAddr="0" DeviceTypeCode="0" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="0" Write_Amount="0" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0" />
              <Block Enable="0" StationAddr="0" DeviceTypeCode="0" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="0" Write_Amount="0" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0" />
              <Block Enable="0" StationAddr="0" DeviceTypeCode="0" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="0" Write_Amount="0" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0" />
              <Block Enable="0" StationAddr="0" DeviceTypeCode="0" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="0" Write_Amount="0" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0" />
              <Block Enable="0" StationAddr="0" DeviceTypeCode="0" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="0" Write_Amount="0" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0" />
              <Block Enable="0" StationAddr="0" DeviceTypeCode="0" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="0" Write_Amount="0" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0" />
              <Block Enable="0" StationAddr="0" DeviceTypeCode="0" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="0" Write_Amount="0" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0" />
              <Block Enable="0" StationAddr="0" DeviceTypeCode="0" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="0" Write_Amount="0" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0" />
              <Block Enable="0" StationAddr="0" DeviceTypeCode="0" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="0" Write_Amount="0" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0" />
              <Block Enable="0" StationAddr="0" DeviceTypeCode="0" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="0" Write_Amount="0" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0" />
              <Block Enable="0" StationAddr="0" DeviceTypeCode="0" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="0" Write_Amount="0" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0" />
              <Block Enable="0" StationAddr="0" DeviceTypeCode="0" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="0" Write_Amount="0" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0" />
              <Block Enable="0" StationAddr="0" DeviceTypeCode="0" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="0" Write_Amount="0" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0" />
              <Block Enable="0" StationAddr="0" DeviceTypeCode="0" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="0" Write_Amount="0" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0" />
              <Block Enable="0" StationAddr="0" DeviceTypeCode="0" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="0" Write_Amount="0" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0" />
              <Block Enable="0" StationAddr="0" DeviceTypeCode="0" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="0" Write_Amount="0" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0" />
              <Block Enable="0" StationAddr="0" DeviceTypeCode="0" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="0" Write_Amount="0" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0" />
              <Block Enable="0" StationAddr="0" DeviceTypeCode="0" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="0" Write_Amount="0" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0" />
              <Block Enable="0" StationAddr="0" DeviceTypeCode="0" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="0" Write_Amount="0" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0" />
              <Block Enable="0" StationAddr="0" DeviceTypeCode="0" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="0" Write_Amount="0" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0" />
            </Blocks>
          </Table>
        </Tables>
      </Port>
      <Port Index="2">
        <Tables>
          <Table ProtocolType="Modbus" Mode="0" AutoScan="0">
            <Blocks>
              <Block Enable="0" StationAddr="0" DeviceTypeCode="0" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="0" Write_Amount="0" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0" />
              <Block Enable="0" StationAddr="0" DeviceTypeCode="0" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="0" Write_Amount="0" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0" />
              <Block Enable="0" StationAddr="0" DeviceTypeCode="0" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="0" Write_Amount="0" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0" />
              <Block Enable="0" StationAddr="0" DeviceTypeCode="0" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="0" Write_Amount="0" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0" />
              <Block Enable="0" StationAddr="0" DeviceTypeCode="0" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="0" Write_Amount="0" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0" />
              <Block Enable="0" StationAddr="0" DeviceTypeCode="0" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="0" Write_Amount="0" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0" />
              <Block Enable="0" StationAddr="0" DeviceTypeCode="0" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="0" Write_Amount="0" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0" />
              <Block Enable="0" StationAddr="0" DeviceTypeCode="0" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="0" Write_Amount="0" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0" />
              <Block Enable="0" StationAddr="0" DeviceTypeCode="0" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="0" Write_Amount="0" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0" />
              <Block Enable="0" StationAddr="0" DeviceTypeCode="0" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="0" Write_Amount="0" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0" />
              <Block Enable="0" StationAddr="0" DeviceTypeCode="0" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="0" Write_Amount="0" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0" />
              <Block Enable="0" StationAddr="0" DeviceTypeCode="0" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="0" Write_Amount="0" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0" />
              <Block Enable="0" StationAddr="0" DeviceTypeCode="0" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="0" Write_Amount="0" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0" />
              <Block Enable="0" StationAddr="0" DeviceTypeCode="0" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="0" Write_Amount="0" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0" />
              <Block Enable="0" StationAddr="0" DeviceTypeCode="0" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="0" Write_Amount="0" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0" />
              <Block Enable="0" StationAddr="0" DeviceTypeCode="0" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="0" Write_Amount="0" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0" />
              <Block Enable="0" StationAddr="0" DeviceTypeCode="0" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="0" Write_Amount="0" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0" />
              <Block Enable="0" StationAddr="0" DeviceTypeCode="0" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="0" Write_Amount="0" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0" />
              <Block Enable="0" StationAddr="0" DeviceTypeCode="0" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="0" Write_Amount="0" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0" />
              <Block Enable="0" StationAddr="0" DeviceTypeCode="0" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="0" Write_Amount="0" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0" />
              <Block Enable="0" StationAddr="0" DeviceTypeCode="0" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="0" Write_Amount="0" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0" />
              <Block Enable="0" StationAddr="0" DeviceTypeCode="0" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="0" Write_Amount="0" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0" />
              <Block Enable="0" StationAddr="0" DeviceTypeCode="0" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="0" Write_Amount="0" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0" />
              <Block Enable="0" StationAddr="0" DeviceTypeCode="0" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="0" Write_Amount="0" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0" />
              <Block Enable="0" StationAddr="0" DeviceTypeCode="0" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="0" Write_Amount="0" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0" />
              <Block Enable="0" StationAddr="0" DeviceTypeCode="0" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="0" Write_Amount="0" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0" />
              <Block Enable="0" StationAddr="0" DeviceTypeCode="0" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="0" Write_Amount="0" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0" />
              <Block Enable="0" StationAddr="0" DeviceTypeCode="0" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="0" Write_Amount="0" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0" />
              <Block Enable="0" StationAddr="0" DeviceTypeCode="0" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="0" Write_Amount="0" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0" />
              <Block Enable="0" StationAddr="0" DeviceTypeCode="0" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="0" Write_Amount="0" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0" />
              <Block Enable="0" StationAddr="0" DeviceTypeCode="0" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="0" Write_Amount="0" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0" />
              <Block Enable="0" StationAddr="0" DeviceTypeCode="0" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="0" Write_Amount="0" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0" />
            </Blocks>
          </Table>
        </Tables>
      </Port>
      <Port Index="3">
        <Tables>
          <Table ProtocolType="ModbusTCP" Mode="2">
            <Blocks>
              <Block Enable="0" StationAddr="256" RemoteIP="192.168.1.1" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="4096" R_FuncCode="768" Interval_Time="2560" TimeOut="12800" AddrType="0" />
              <Block Enable="0" StationAddr="0" RemoteIP="0.0.0.0" DeviceTypeCode="0" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="0" Write_Amount="0" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0" />
              <Block Enable="0" StationAddr="0" RemoteIP="0.0.0.0" DeviceTypeCode="0" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="0" Write_Amount="0" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0" />
              <Block Enable="0" StationAddr="0" RemoteIP="0.0.0.0" DeviceTypeCode="0" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="0" Write_Amount="0" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0" />
              <Block Enable="0" StationAddr="0" RemoteIP="0.0.0.0" DeviceTypeCode="0" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="0" Write_Amount="0" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0" />
              <Block Enable="0" StationAddr="0" RemoteIP="0.0.0.0" DeviceTypeCode="0" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="0" Write_Amount="0" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0" />
              <Block Enable="0" StationAddr="0" RemoteIP="0.0.0.0" DeviceTypeCode="0" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="0" Write_Amount="0" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0" />
              <Block Enable="0" StationAddr="0" RemoteIP="0.0.0.0" DeviceTypeCode="0" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="0" Write_Amount="0" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0" />
              <Block Enable="0" StationAddr="0" RemoteIP="0.0.0.0" DeviceTypeCode="0" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="0" Write_Amount="0" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0" />
              <Block Enable="0" StationAddr="0" RemoteIP="0.0.0.0" DeviceTypeCode="0" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="0" Write_Amount="0" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0" />
              <Block Enable="0" StationAddr="0" RemoteIP="0.0.0.0" DeviceTypeCode="0" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="0" Write_Amount="0" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0" />
              <Block Enable="0" StationAddr="0" RemoteIP="0.0.0.0" DeviceTypeCode="0" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="0" Write_Amount="0" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0" />
              <Block Enable="0" StationAddr="0" RemoteIP="0.0.0.0" DeviceTypeCode="0" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="0" Write_Amount="0" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0" />
              <Block Enable="0" StationAddr="0" RemoteIP="0.0.0.0" DeviceTypeCode="0" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="0" Write_Amount="0" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0" />
              <Block Enable="0" StationAddr="0" RemoteIP="0.0.0.0" DeviceTypeCode="0" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="0" Write_Amount="0" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0" />
              <Block Enable="0" StationAddr="0" RemoteIP="0.0.0.0" DeviceTypeCode="0" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="0" Write_Amount="0" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0" />
            </Blocks>
          </Table>
        </Tables>
      </Port>
    </Ports>
  </TotalData>
</Configuration>